// ========== ОСНОВНЫЕ ФУНКЦИИ ==========

/**
 * Функция sum - принимает любое количество аргументов
 * Использует rest parameters для получения всех аргументов
 */
function sum(...numbers) {
    return numbers.reduce((total, num) => total + num, 0);
}

/**
 * Функция createUser - принимает объект с деструктуризацией
 * Объект должен содержать: name, age, email (email - необязательный)
 */
function createUser({ name, age, email = "не указан" }) {
    return `Пользователь: ${name}, возраст: ${age}, email: ${email}`;
}

/**
 * Функция secretMessage - сохраняет секретное сообщение
 * и возвращает функцию для его проверки (замыкание)
 */
function secretMessage(password, message) {
    return function(checkPassword) {
        return checkPassword === password ? message : "Доступ запрещен";
    };
}

// ========== РЕКУРСИЯ И ФУНКЦИИ ВЫСШЕГО ПОРЯДКА ==========

/**
 * Функция compose - принимает несколько функций
 * и возвращает их композицию
 */
function compose(...functions) {
    return function(initialValue) {
        return functions.reduceRight((value, fn) => fn(value), initialValue);
    };
}

/**
 * Функция myMap - работает как Array.prototype.map
 */
function myMap(array, callback) {
    const result = [];
    for (let i = 0; i < array.length; i++) {
        result.push(callback(array[i], i, array));
    }
    return result;
}

/**
 * Функция myFilter - работает как Array.prototype.filter
 */
function myFilter(array, callback) {
    const result = [];
    for (let i = 0; i < array.length; i++) {
        if (callback(array[i], i, array)) {
            result.push(array[i]);
        }
    }
    return result;
}

/**
 * Функция myReduce - работает как Array.prototype.reduce
 */
function myReduce(array, callback, initialValue) {
    let accumulator = initialValue !== undefined ? initialValue : array[0];
    let startIndex = initialValue !== undefined ? 0 : 1;
    
    for (let i = startIndex; i < array.length; i++) {
        accumulator = callback(accumulator, array[i], i, array);
    }
    
    return accumulator;
}

// ========== СЛОЖНЫЕ ФУНКЦИИ ==========

/**
 * Функция curry - превращает функцию от нескольких аргументов в цепочку функций
 */
function curry(fn) {
    return function curried(...args) {
        if (args.length >= fn.length) {
            return fn.apply(this, args);
        } else {
            return function(...args2) {
                return curried.apply(this, args.concat(args2));
            };
        }
    };
}

/**
 * Функция memoize - кэширует результаты вызовов функции
 */
function memoize(fn) {
    const cache = new Map();
    
    return function(...args) {
        const key = JSON.stringify(args);
        
        if (cache.has(key)) {
            console.log('Возвращаем кэшированный результат для:', args);
            return cache.get(key);
        }
        
        console.log('Вычисляем новый результат для:', args);
        const result = fn.apply(this, args);
        cache.set(key, result);
        return result;
    };
}

/**
 * Функция debounce - откладывает вызов функции
 */
function debounce(fn, delay) {
    let timeoutId;
    
    return function(...args) {
        clearTimeout(timeoutId);
        
        timeoutId = setTimeout(() => {
            fn.apply(this, args);
        }, delay);
    };
}

/**
 * Функция throttle - ограничивает частоту вызовов функции
 */
function throttle(fn, interval) {
    let lastCallTime = 0;
    let timeoutId;
    
    return function(...args) {
        const currentTime = Date.now();
        const timeSinceLastCall = currentTime - lastCallTime;
        
        if (timeSinceLastCall >= interval) {
            lastCallTime = currentTime;
            fn.apply(this, args);
        } else {
            clearTimeout(timeoutId);
            timeoutId = setTimeout(() => {
                lastCallTime = Date.now();
                fn.apply(this, args);
            }, interval - timeSinceLastCall);
        }
    };
}

/**
 * Функция createValidator - возвращает функцию проверки
 * Валидатор проверяет: минимальную длину, наличие цифр, наличие заглавных букв
 */
function createValidator(options = {}) {
    const {
        minLength = 0,
        requireDigits = false,
        requireUppercase = false
    } = options;
    
    return function(value) {
        const errors = [];
        
        if (value.length < minLength) {
            errors.push(`Минимальная длина: ${minLength} символов`);
        }
        
        if (requireDigits && !/\d/.test(value)) {
            errors.push('Требуется хотя бы одна цифра');
        }
        
        if (requireUppercase && !/[A-ZА-Я]/.test(value)) {
            errors.push('Требуется хотя бы одна заглавная буква');
        }
        
        return {
            isValid: errors.length === 0,
            errors: errors
        };
    };
}

// Демонстрационные функции для тестирования
const slowFunction = (a, b) => {
    // Имитация тяжелых вычислений
    for (let i = 0; i < 1000000; i++) { }
    return a + b;
};

const memoizedSlowFunction = memoize(slowFunction);

// Экспорт функций для использования в тестах
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        sum,
        createUser,
        secretMessage,
        compose,
        myMap,
        myFilter,
        myReduce,
        curry,
        memoize,
        debounce,
        throttle,
        createValidator
    };
}