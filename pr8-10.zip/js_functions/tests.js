
let testCount = 0;
let passedTests = 0;
let failedTests = 0;

// ========== СИСТЕМА ТЕСТИРОВАНИЯ ==========

function runAllTests() {
    console.log('=== ЗАПУСК ВСЕХ ТЕСТОВ ===');
    
    resetTestCounters();
    clearTestResults();
    addTestResult('=== ЗАПУСК ВСЕХ ТЕСТОВ ===', 'header');
    
    testBasicFunctions();
    testRecursionAndHOF();
    testAdvancedFunctions();
    
    const summary = `\n=== ИТОГИ ТЕСТИРОВАНИЯ ===\nПройдено: ${passedTests}/${testCount} тестов\nНе пройдено: ${failedTests} тестов`;
    addTestResult(summary, failedTests === 0 ? 'success' : 'error');
    
    // Демонстрация работы функций
    demonstrateFunctions();
    
    console.log(summary);
}

function resetTestCounters() {
    testCount = 0;
    passedTests = 0;
    failedTests = 0;
}

function clearTestResults() {
    const resultsDiv = document.getElementById('test-results');
    resultsDiv.innerHTML = '<p class="test-placeholder">Результаты тестов появятся здесь после запуска</p>';
}

function addTestResult(message, type = 'info') {
    const resultsDiv = document.getElementById('test-results');
    
    if (resultsDiv.querySelector('.test-placeholder')) {
        resultsDiv.innerHTML = '';
    }
    
    const resultElement = document.createElement('div');
    resultElement.className = `test-result ${type}`;
    
    const formattedMessage = message.replace(/\n/g, '<br>');
    resultElement.innerHTML = formattedMessage;
    
    resultsDiv.appendChild(resultElement);
    resultsDiv.scrollTop = resultsDiv.scrollHeight;
}

function assert(condition, message) {
    testCount++;
    if (condition) {
        passedTests++;
        addTestResult(`✓ ${message}`, 'success');
        console.log(`✓ ${message}`);
    } else {
        failedTests++;
        addTestResult(`✗ ${message}`, 'error');
        console.error(`✗ ${message}`);
    }
}

// ========== ТЕСТЫ ОСНОВНЫХ ФУНКЦИЙ ==========

function testBasicFunctions() {
    addTestResult('\n--- ТЕСТИРОВАНИЕ ОСНОВНЫХ ФУНКЦИЙ ---', 'section');
    
    // Тесты для sum
    assert(sum(1, 2, 3) === 6, 'sum(1, 2, 3) = 6');
    assert(sum() === 0, 'sum() без аргументов = 0');
    assert(sum(5) === 5, 'sum(5) = 5');
    assert(sum(1, -2, 3, -4) === -2, 'sum(1, -2, 3, -4) = -2');
    
    // Тесты для createUser
    assert(createUser({ name: 'Иван', age: 25 }) === 'Пользователь: Иван, возраст: 25, email: не указан', 
        'createUser с обязательными полями');
    assert(createUser({ name: 'Мария', age: 30, email: 'maria@example.com' }) === 'Пользователь: Мария, возраст: 30, email: maria@example.com', 
        'createUser с email');
    
    // Тесты для secretMessage
    const secret = secretMessage('123', 'Секретное сообщение');
    assert(secret('123') === 'Секретное сообщение', 'secretMessage с правильным паролем');
    assert(secret('wrong') === 'Доступ запрещен', 'secretMessage с неправильным паролем');
}

// ========== ТЕСТЫ РЕКУРСИИ И HOF ==========

function testRecursionAndHOF() {
    addTestResult('\n--- ТЕСТИРОВАНИЕ РЕКУРСИИ И ФУНКЦИЙ ВЫСШЕГО ПОРЯДКА ---', 'section');
    
    // Тесты для compose
    const add5 = x => x + 5;
    const multiply3 = x => x * 3;
    const subtract2 = x => x - 2;
    
    const composed = compose(subtract2, multiply3, add5);
    assert(composed(5) === 28, 'compose: (5 + 5) * 3 - 2 = 28');
    
    // Тесты для myMap
    const numbers = [1, 2, 3, 4];
    const doubled = myMap(numbers, x => x * 2);
    assert(JSON.stringify(doubled) === JSON.stringify([2, 4, 6, 8]), 
        'myMap: удвоение элементов массива');
    
    // Тесты для myFilter
    const evenNumbers = myFilter(numbers, x => x % 2 === 0);
    assert(JSON.stringify(evenNumbers) === JSON.stringify([2, 4]), 
        'myFilter: фильтрация четных чисел');
    
    // Тесты для myReduce
    const sumResult = myReduce(numbers, (acc, val) => acc + val, 0);
    assert(sumResult === 10, 'myReduce: сумма элементов массива = 10');
    
    const productResult = myReduce(numbers, (acc, val) => acc * val, 1);
    assert(productResult === 24, 'myReduce: произведение элементов массива = 24');
}

// ========== ТЕСТЫ ПРОДВИНУТЫХ ФУНКЦИЙ ==========

function testAdvancedFunctions() {
    addTestResult('\n--- ТЕСТИРОВАНИЕ ПРОДВИНУТЫХ ФУНКЦИЙ ---', 'section');
    
    // Тесты для curry
    const multiply = (a, b, c) => a * b * c;
    const curriedMultiply = curry(multiply);
    
    assert(curriedMultiply(2)(3)(4) === 24, 'curry: 2 * 3 * 4 = 24');
    assert(curriedMultiply(2, 3)(4) === 24, 'curry: (2, 3) * 4 = 24');
    assert(curriedMultiply(2)(3, 4) === 24, 'curry: 2 * (3, 4) = 24');
    
    // Тесты для memoize
    let callCount = 0;
    const expensiveFunction = (a, b) => {
        callCount++;
        return a + b;
    };
    
    const memoized = memoize(expensiveFunction);
    memoized(1, 2);
    memoized(1, 2);
    memoized(1, 2);
    
    assert(callCount === 1, 'memoize: функция вызывается только один раз для одинаковых аргументов');
    
    // Тесты для debounce и throttle (демонстрационные)
    let debounceCount = 0;
    const debouncedFn = debounce(() => debounceCount++, 100);
    
    let throttleCount = 0;
    const throttledFn = throttle(() => throttleCount++, 100);
    
    // Тесты для createValidator
    const passwordValidator = createValidator({
        minLength: 6,
        requireDigits: true,
        requireUppercase: true
    });
    
    const weakResult = passwordValidator('weak');
    const strongResult = passwordValidator('Strong123');
    
    assert(weakResult.isValid === false, 'Валидатор: слабый пароль не проходит проверку');
    assert(strongResult.isValid === true, 'Валидатор: сильный пароль проходит проверку');
    assert(weakResult.errors.length === 3, 'Валидатор: слабый пароль имеет 3 ошибки');
}

// ========== ДЕМОНСТРАЦИЯ РАБОТЫ ФУНКЦИЙ ==========

function demonstrateFunctions() {
    const demoDiv = document.getElementById('demo-results');
    demoDiv.innerHTML = '<h4>Демонстрация работы функций:</h4>';
    
    // Демонстрация sum
    demoDiv.innerHTML += `<p>sum(1, 2, 3, 4, 5) = ${sum(1, 2, 3, 4, 5)}</p>`;
    
    // Демонстрация createUser
    demoDiv.innerHTML += `<p>${createUser({ name: 'Анна', age: 28, email: 'anna@example.com' })}</p>`;
    
    // Демонстрация secretMessage
    const secret = secretMessage('qwerty', 'Тайное послание');
    demoDiv.innerHTML += `<p>secretMessage('qwerty'): "${secret('qwerty')}"</p>`;
    demoDiv.innerHTML += `<p>secretMessage('wrong'): "${secret('wrong')}"</p>`;
    
    // Демонстрация compose
    const add10 = x => x + 10;
    const multiply2 = x => x * 2;
    const composed = compose(multiply2, add10);
    demoDiv.innerHTML += `<p>compose(multiply2, add10)(5) = ${composed(5)}</p>`;
    
    // Демонстрация валидатора
    const validator = createValidator({ minLength: 3, requireDigits: true });
    const testPassword = 'pass1';
    const validation = validator(testPassword);
    demoDiv.innerHTML += `<p>Валидация "${testPassword}": ${validation.isValid ? 'VALID' : 'INVALID'}</p>`;
    if (!validation.isValid) {
        demoDiv.innerHTML += `<p>Ошибки: ${validation.errors.join(', ')}</p>`;
    }
    
    // Демонстрация каррирования
    const add = (a, b, c) => a + b + c;
    const curriedAdd = curry(add);
    demoDiv.innerHTML += `<p>curry(add)(1)(2)(3) = ${curriedAdd(1)(2)(3)}</p>`;
}

// ========== ОТДЕЛЬНЫЕ ТЕСТЫ ДЛЯ КНОПОК ==========

function runBasicFunctionsTests() {
    resetTestCounters();
    clearTestResults();
    addTestResult('--- ТЕСТИРОВАНИЕ ОСНОВНЫХ ФУНКЦИЙ ---', 'section');
    testBasicFunctions();
    addTestResult(`\nПройдено: ${passedTests}/${testCount} тестов`, 'info');
    demonstrateFunctions();
}

function runRecursionAndHOFTests() {
    resetTestCounters();
    clearTestResults();
    addTestResult('--- ТЕСТИРОВАНИЕ РЕКУРСИИ И HOF ---', 'section');
    testRecursionAndHOF();
    addTestResult(`\nПройдено: ${passedTests}/${testCount} тестов`, 'info');
    demonstrateFunctions();
}

function runAdvancedFunctionsTests() {
    resetTestCounters();
    clearTestResults();
    addTestResult('--- ТЕСТИРОВАНИЕ ПРОДВИНУТЫХ ФУНКЦИЙ ---', 'section');
    testAdvancedFunctions();
    addTestResult(`\nПройдено: ${passedTests}/${testCount} тестов`, 'info');
    demonstrateFunctions();
}

// Автоматический запуск при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    console.log('Система тестирования функций загружена');
    addTestResult('Система тестирования готова. Нажмите "Запустить все тесты" для проверки функций.', 'info');
});