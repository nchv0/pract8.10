/**
 * Проверяет, является ли число простым
 * Временная сложность: O(√n)
 */
function isPrime(number) {
    if (number <= 1) return false;
    if (number <= 3) return true;
    if (number % 2 === 0 || number % 3 === 0) return false;
    
    // Проверяем делители до √n
    for (let i = 5; i * i <= number; i += 6) {
        if (number % i === 0 || number % (i + 2) === 0) return false;
    }
    return true;
}

/**
 * Вычисляет факториал числа
 * Временная сложность: O(n)
 */
function factorial(n) {
    if (n < 0) throw new Error("Факториал отрицательного числа не определен");
    if (n === 0 || n === 1) return 1;
    
    let result = 1;
    for (let i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}

/**
 * Возвращает массив первых n чисел Фибоначчи
 * Временная сложность: O(n)
 */
function fibonacci(n) {
    if (n <= 0) return [];
    if (n === 1) return [0];
    if (n === 2) return [0, 1];
    
    const sequence = [0, 1];
    for (let i = 2; i < n; i++) {
        sequence[i] = sequence[i - 1] + sequence[i - 2];
    }
    return sequence;
}

/**
 * Находит наибольший общий делитель двух чисел (алгоритм Евклида)
 */
function gcd(a, b) {
    // Обработка отрицательных чисел
    a = Math.abs(a);
    b = Math.abs(b);
    
    while (b !== 0) {
        const temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

// ========== ФУНКЦИИ ДЛЯ РАБОТЫ СО СТРОКАМИ ==========

/**
 * Проверяет, является ли строка палиндромом
 * Временная сложность: O(n)
 */
function isPalindrome(str) {
    // Приводим к нижнему регистру и удаляем пробелы
    const cleanStr = str.toLowerCase().replace(/\s+/g, '');
    let left = 0;
    let right = cleanStr.length - 1;
    
    while (left < right) {
        if (cleanStr[left] !== cleanStr[right]) return false;
        left++;
        right--;
    }
    return true;
}

/**
 * Подсчитывает количество гласных букв в строке
 * Временная сложность: O(n)
 */
function countVowels(str) {
    const vowels = {
        'russian': 'аеёиоуыэюя',
        'english': 'aeiou'
    };
    
    const allVowels = vowels.russian + vowels.english;
    let count = 0;
    
    for (let char of str.toLowerCase()) {
        if (allVowels.includes(char)) {
            count++;
        }
    }
    return count;
}

/**
 * Переворачивает строку без использования встроенных методов
 * Временная сложность: O(n)
 */
function reverseString(str) {
    let reversed = '';
    for (let i = str.length - 1; i >= 0; i--) {
        reversed += str[i];
    }
    return reversed;
}

/**
 * Находит самое длинное слово в предложении
 * Временная сложность: O(n)
 */
function findLongestWord(sentence) {
    const words = sentence.split(/\s+/);
    let longestWord = '';
    let maxLength = 0;
    
    for (let word of words) {
        // Удаляем знаки препинания для точного подсчета
        const cleanWord = word.replace(/[.,!?;:]/g, '');
        if (cleanWord.length > maxLength) {
            maxLength = cleanWord.length;
            longestWord = cleanWord;
        }
    }
    return longestWord;
}

// ========== ФУНКЦИИ ДЛЯ РАБОТЫ С МАССИВАМИ ==========

/**
 * Находит максимальный элемент в массиве
 * Временная сложность: O(n)
 */
function findMax(arr) {
    if (arr.length === 0) throw new Error("Массив пуст");
    
    let max = arr[0];
    for (let i = 1; i < arr.length; i++) {
        if (arr[i] > max) {
            max = arr[i];
        }
    }
    return max;
}

/**
 * Удаляет дубликаты из массива
 * Временная сложность: O(n)
 */
function removeDuplicates(arr) {
    const seen = new Set();
    const result = [];
    
    for (let item of arr) {
        if (!seen.has(item)) {
            seen.add(item);
            result.push(item);
        }
    }
    return result;
}

/**
 * Сортирует массив методом пузырьковой сортировки
 * Временная сложность: O(n²)
 */
function bubbleSort(arr) {
    const n = arr.length;
    let swapped;
    
    for (let i = 0; i < n - 1; i++) {
        swapped = false;
        for (let j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                // Меняем элементы местами
                [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
                swapped = true;
            }
        }
        // Если не было обменов, массив уже отсортирован
        if (!swapped) break;
    }
    return arr;
}

/**
 * Находит элемент в отсортированном массиве методом бинарного поиска
 * Временная сложность: O(log n)
 */
function binarySearch(sortedArr, target) {
    let left = 0;
    let right = sortedArr.length - 1;
    
    while (left <= right) {
        const mid = Math.floor((left + right) / 2);
        
        if (sortedArr[mid] === target) {
            return mid;
        } else if (sortedArr[mid] < target) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    return -1;
}

// ========== УТИЛИТАРНЫЕ ФУНКЦИИ ==========

/**
 * Форматирует денежную сумму в читаемый вид
 * Временная сложность: O(1)
 */
function formatCurrency(amount, currency = '₽') {
    // Округляем до 2 знаков после запятой
    const roundedAmount = Math.round(amount * 100) / 100;
    
    // Разделяем целую и дробную части
    const [integerPart, fractionalPart] = roundedAmount.toString().split('.');
    
    // Добавляем пробелы между тысячами
    const formattedInteger = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    
    // Обеспечиваем 2 знака после запятой
    const formattedFractional = fractionalPart ? 
        fractionalPart.padEnd(2, '0') : '00';
    
    return `${formattedInteger}.${formattedFractional} ${currency}`;
}

/**
 * Проверяет валидность email адреса с помощью регулярного выражения
 * Временная сложность: O(1)
 */
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

/**
 * Генерирует случайный пароль заданной длины
 * Временная сложность: O(n)
 */
function generatePassword(length = 8) {
    const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lowercase = 'abcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';
    const specialChars = '!@#$%^&*()_+-=[]{}|;:,.<>?';
    
    const allChars = uppercase + lowercase + numbers + specialChars;
    let password = '';
    
    // Гарантируем наличие хотя бы одного символа каждого типа
    password += uppercase[Math.floor(Math.random() * uppercase.length)];
    password += lowercase[Math.floor(Math.random() * lowercase.length)];
    password += numbers[Math.floor(Math.random() * numbers.length)];
    password += specialChars[Math.floor(Math.random() * specialChars.length)];
    
    // Заполняем оставшуюся длину случайными символами
    for (let i = 4; i < length; i++) {
        password += allChars[Math.floor(Math.random() * allChars.length)];
    }
    
    // Перемешиваем пароль для случайного порядка символов
    return password.split('').sort(() => Math.random() - 0.5).join('');
}