let testCount = 0;
let passedTests = 0;
let failedTests = 0;

function runAllTests() {
    console.log('=== ЗАПУСК ВСЕХ ТЕСТОВ ===\n');
    
    resetTestCounters();
    clearTestResults();
    addTestResult('=== ЗАПУСК ВСЕХ ТЕСТОВ ===', 'header');
    
    testNumberFunctions();
    testStringFunctions();
    testArrayFunctions();
    testUtilityFunctions();
    
    const summary = `\n=== ИТОГИ ТЕСТИРОВАНИЯ ===\nПройдено: ${passedTests}/${testCount} тестов\nНе пройдено: ${failedTests} тестов`;
    addTestResult(summary, failedTests === 0 ? 'success' : 'error');
    
    console.log(summary);
}

function resetTestCounters() {
    testCount = 0;
    passedTests = 0;
    failedTests = 0;
}

function clearTestResults() {
    const resultsDiv = document.getElementById('test-results');
    resultsDiv.innerHTML = '<p class="test-placeholder">Результаты тестов появятся здесь после запуска</p>';
}

function addTestResult(message, type = 'info') {
    const resultsDiv = document.getElementById('test-results');
    
    // Убираем placeholder при первом результате
    if (resultsDiv.querySelector('.test-placeholder')) {
        resultsDiv.innerHTML = '';
    }
    
    const resultElement = document.createElement('div');
    resultElement.className = `test-result ${type}`;
    
    // Форматируем сообщение с сохранением переносов строк
    const formattedMessage = message.replace(/\n/g, '<br>');
    resultElement.innerHTML = formattedMessage;
    
    resultsDiv.appendChild(resultElement);
    resultsDiv.scrollTop = resultsDiv.scrollHeight;
}

function assert(condition, message) {
    testCount++;
    if (condition) {
        passedTests++;
        addTestResult(`✓ ${message}`, 'success');
        console.log(`✓ ${message}`);
    } else {
        failedTests++;
        addTestResult(`✗ ${message}`, 'error');
        console.error(`✗ ${message}`);
    }
}

function testNumberFunctions() {
    addTestResult('\n--- ТЕСТИРОВАНИЕ ФУНКЦИЙ ДЛЯ РАБОТЫ С ЧИСЛАМИ ---', 'section');
    
    // Тесты для isPrime
    assert(isPrime(2) === true, '2 должно быть простым числом');
    assert(isPrime(17) === true, '17 должно быть простым числом');
    assert(isPrime(15) === false, '15 не должно быть простым числом');
    assert(isPrime(1) === false, '1 не должно быть простым числом');
    assert(isPrime(97) === true, '97 должно быть простым числом');
    
    // Тесты для factorial
    assert(factorial(0) === 1, '0! должно быть равно 1');
    assert(factorial(5) === 120, '5! должно быть равно 120');
    assert(factorial(3) === 6, '3! должно быть равно 6');
    
    // Тесты для fibonacci
    assert(JSON.stringify(fibonacci(5)) === JSON.stringify([0, 1, 1, 2, 3]), 
        'Первые 5 чисел Фибоначчи: [0, 1, 1, 2, 3]');
    assert(JSON.stringify(fibonacci(1)) === JSON.stringify([0]), 
        'Первое число Фибоначчи: [0]');
    assert(fibonacci(0).length === 0, '0 чисел Фибоначчи: пустой массив');
    assert(JSON.stringify(fibonacci(7)) === JSON.stringify([0, 1, 1, 2, 3, 5, 8]), 
        'Первые 7 чисел Фибоначчи: [0, 1, 1, 2, 3, 5, 8]');
    
    // Тесты для gcd
    assert(gcd(48, 18) === 6, 'НОД(48, 18) = 6');
    assert(gcd(17, 13) === 1, 'НОД(17, 13) = 1');
    assert(gcd(0, 5) === 5, 'НОД(0, 5) = 5');
    assert(gcd(100, 25) === 25, 'НОД(100, 25) = 25');
}

function testStringFunctions() {
    addTestResult('\n--- ТЕСТИРОВАНИЕ ФУНКЦИЙ ДЛЯ РАБОТЫ СО СТРОКАМИ ---', 'section');
    
    // Тесты для isPalindrome
    assert(isPalindrome('А роза упала на лапу Азора') === true, 
        '"А роза упала на лапу Азора" должно быть палиндромом');
    assert(isPalindrome('hello') === false, 
        '"hello" не должно быть палиндромом');
    assert(isPalindrome('a') === true, 
        'Одиночный символ должно быть палиндромом');
    assert(isPalindrome('топот') === true, 
        '"топот" должно быть палиндромом');
    
    // Тесты для countVowels
    assert(countVowels('Привет, мир!') === 3, 
        '"Привет, мир!" содержит 3 гласные');
    assert(countVowels('JavaScript') === 3, 
        '"JavaScript" содержит 3 гласные');
    assert(countVowels('БВГД') === 0, 
        'Строка без гласных должна возвращать 0');
    assert(countVowels('Аэрофотосъёмка') === 7, 
        '"Аэрофотосъёмка" содержит 7 гласных');
    
    // Тесты для reverseString
    assert(reverseString('hello') === 'olleh', 
        'reverseString("hello") = "olleh"');
    assert(reverseString('а') === 'а', 
        'reverseString("а") = "а"');
    assert(reverseString('') === '', 
        'reverseString("") = ""');
    assert(reverseString('JavaScript') === 'tpircSavaJ', 
        'reverseString("JavaScript") = "tpircSavaJ"');
    
    // Тесты для findLongestWord
    assert(findLongestWord('Самое длинное слово в предложении') === 'предложении', 
        'Самое длинное слово: "предложении"');
    assert(findLongestWord('hello world') === 'hello', 
        'Самое длинное слово: "hello"');
    assert(findLongestWord('a bb ccc') === 'ccc', 
        'Самое длинное слово: "ccc"');
}

function testArrayFunctions() {
    addTestResult('\n--- ТЕСТИРОВАНИЕ ФУНКЦИЙ ДЛЯ РАБОТЫ С МАССИВАМИ ---', 'section');
    
    // Тесты для findMax
    assert(findMax([1, 5, 3, 9, 2]) === 9, 
        'Максимум в [1, 5, 3, 9, 2] = 9');
    assert(findMax([-1, -5, -3]) === -1, 
        'Максимум в [-1, -5, -3] = -1');
    assert(findMax([42]) === 42, 
        'Максимум в [42] = 42');
    
    // Тесты для removeDuplicates
    assert(JSON.stringify(removeDuplicates([1, 2, 2, 3, 4, 4, 5])) === 
        JSON.stringify([1, 2, 3, 4, 5]), 
        'removeDuplicates([1,2,2,3,4,4,5]) = [1,2,3,4,5]');
    assert(JSON.stringify(removeDuplicates([1, 1, 1])) === 
        JSON.stringify([1]), 
        'removeDuplicates([1,1,1]) = [1]');
    assert(JSON.stringify(removeDuplicates([])) === 
        JSON.stringify([]), 
        'removeDuplicates([]) = []');
    
    // Тесты для bubbleSort
    assert(JSON.stringify(bubbleSort([5, 3, 8, 1, 2])) === 
        JSON.stringify([1, 2, 3, 5, 8]), 
        'bubbleSort([5,3,8,1,2]) = [1,2,3,5,8]');
    assert(JSON.stringify(bubbleSort([1])) === 
        JSON.stringify([1]), 
        'bubbleSort([1]) = [1]');
    assert(JSON.stringify(bubbleSort([3, 2, 1])) === 
        JSON.stringify([1, 2, 3]), 
        'bubbleSort([3,2,1]) = [1,2,3]');
    
    // Тесты для binarySearch
    const sortedArray = [1, 3, 5, 7, 9, 11, 13];
    assert(binarySearch(sortedArray, 7) === 3, 
        'binarySearch([1,3,5,7,9,11,13], 7) = 3');
    assert(binarySearch(sortedArray, 10) === -1, 
        'binarySearch([1,3,5,7,9,11,13], 10) = -1');
    assert(binarySearch(sortedArray, 1) === 0, 
        'binarySearch([1,3,5,7,9,11,13], 1) = 0');
    assert(binarySearch([], 5) === -1, 
        'binarySearch([], 5) = -1');
}

function testUtilityFunctions() {
    addTestResult('\n--- ТЕСТИРОВАНИЕ УТИЛИТАРНЫХ ФУНКЦИЙ ---', 'section');
    
    // Тесты для formatCurrency
    assert(formatCurrency(1234.56) === '1 234.56 ₽', 
        'formatCurrency(1234.56) = "1 234.56 ₽"');
    assert(formatCurrency(1000) === '1 000.00 ₽', 
        'formatCurrency(1000) = "1 000.00 ₽"');
    assert(formatCurrency(1234567.89, '$') === '1 234 567.89 $', 
        'formatCurrency(1234567.89, "$") = "1 234 567.89 $"');
    
    // Тесты для isValidEmail
    assert(isValidEmail('test@example.com') === true, 
        'test@example.com должен быть валидным email');
    assert(isValidEmail('invalid-email') === false, 
        'invalid-email должен быть невалидным email');
    assert(isValidEmail('user@domain') === false, 
        'user@domain должен быть невалидным email');
    assert(isValidEmail('user.name@domain.co.uk') === true, 
        'user.name@domain.co.uk должен быть валидным email');
    
    // Тесты для generatePassword
    const password = generatePassword(10);
    assert(password.length === 10, 
        `generatePassword(10) должен возвращать пароль длиной 10 символов`);
    
    // Проверяем, что пароль содержит разные типы символов
    const hasUppercase = /[A-Z]/.test(password);
    const hasLowercase = /[a-z]/.test(password);
    const hasNumber = /\d/.test(password);
    const hasSpecial = /[!@#$%^&*()_+\-=\[\]{}|;:,.<>?]/.test(password);
    
    assert(hasUppercase, 'Пароль должен содержать заглавные буквы');
    assert(hasLowercase, 'Пароль должен содержать строчные буквы');
    assert(hasNumber, 'Пароль должен содержать цифры');
    assert(hasSpecial, 'Пароль должен содержать специальные символы');
    
    // Демонстрация сгенерированного пароля
    addTestResult(`Сгенерированный пароль (10 символов): ${password}`, 'info');
}

// Автоматический запуск тестов при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    console.log('Добро пожаловать в тестирование алгоритмов!');
    console.log('Для запуска тестов нажмите кнопку "Запустить все тесты"');
    
    // Добавляем информацию о загрузке
    addTestResult('Система тестирования загружена. Нажмите "Запустить все тесты" для начала проверки.', 'info');
});